const Fastify = require('fastify');
const fastifyCookie = require('@fastify/cookie');
const fastifyFormbody = require('@fastify/formbody');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const JWT_SECRET = process.env.JWT_SECRET || "5add432364493ce76a0f8500393dd661887db381";
const MONGO_URI = process.env.MONGO_URI || "mongodb+srv://ercool877:rvvEHW0F48KGBlQS@cluster0.uvsarvi.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

const fastify = Fastify();

fastify.register(fastifyFormbody);
fastify.register(fastifyCookie);

// Discord ping on boot
axios.post("https://discord.com/api/webhooks/1389802492279390318/WDOQ-847mQBbIOujXK8pIS7OS0LT5fnQol1TKcRD821rrDXz3p41LdPsXezeVa66xvPa", {
  content: "✅ Backend is live on Render.com!"
}).catch(() => {});

// MongoDB connection caching
let cached = global.mongoose;
if (!cached) {
  cached = global.mongoose = { conn: null, promise: null };
}

async function connectDB() {
  if (cached.conn) return cached.conn;

  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      bufferCommands: false,
      serverSelectionTimeoutMS: 5000,
      maxPoolSize: 10,
      socketTimeoutMS: 45000,
    });
  }

  try {
    cached.conn = await cached.promise;
    return cached.conn;
  } catch (error) {
    cached.promise = null;
    throw error;
  }
}

const User = mongoose.model('User', new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  email: { type: String, unique: true, required: true },
  passwordHash: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
}));

function authMiddleware(request, reply, done) {
  const token = request.cookies.token;
  if (!token) return reply.status(401).send({ error: 'Not authenticated' });

  try {
    request.user = jwt.verify(token, JWT_SECRET);
    done();
  } catch (err) {
    reply.status(403).send({ error: 'Invalid or expired token' });
  }
}

function sendHTML(file) {
  return (request, reply) => {
    const filePath = path.join(__dirname, file);
    fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        console.error(`Failed to load ${file}:`, err);
        return reply.status(500).send('Failed to load page');
      }
      reply.type('text/html').send(data);
    });
  };
}

// Routes
fastify.get('/', sendHTML('index.html'));
fastify.get('/signup', sendHTML('api/signup'));
fastify.get('/login', sendHTML('api/login'));
fastify.get('/market', sendHTML('market.html'));

fastify.post('/api/signup', async (request, reply) => {
  try {
    const { username, email, password } = request.body;
    await connectDB();

    if (!username || !password || !email) {
      return reply.status(400).send({ error: "Username, email, and password are required" });
    }

    if (username.length < 3) {
      return reply.status(400).send({ error: "Username must be at least 3 characters" });
    }

    if (password.length < 6) {
      return reply.status(400).send({ error: "Password must be at least 6 characters" });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return reply.status(400).send({ error: "Invalid email address" });
    }

    const exists = await User.findOne({ username });
    if (exists) {
      return reply.status(409).send({ error: "Username already exists" });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = new User({ username, email, passwordHash });
    await user.save();

    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '7d' });

    reply
      .setCookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
      })
      .status(201)
      .send({ message: "Account created successfully", username });
  } catch (err) {
    console.error('Signup error:', err);
    if (err.code === 11000) {
      return reply.status(409).send({ error: "Username or email already exists" });
    }
    reply.status(500).send({ error: "Signup failed" });
  }
});

fastify.post('/api/login', async (request, reply) => {
  try {
    await connectDB();
    const { username, password } = request.body;
    if (!username || !password) return reply.status(400).send({ error: "Username and password are required" });

    const user = await User.findOne({ username });
    if (!user) return reply.status(401).send({ error: "Invalid credentials" });

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) return reply.status(401).send({ error: "Invalid credentials" });

    const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '7d' });

    reply
      .setCookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000,
      })
      .send({ message: "Login successful", username });
  } catch (err) {
    console.error('Login error:', err);
    reply.status(500).send({ error: "Login failed" });
  }
});

fastify.post('/api/logout', (request, reply) => {
  reply
    .clearCookie('token', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
    })
    .send({ message: "Logged out successfully" });
});

fastify.get('/api/me', { preHandler: authMiddleware }, (request, reply) => {
  reply.send({ username: request.user.username });
});

fastify.get('/api/health', (request, reply) => {
  reply.send({
    status: 'OK',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

fastify.setNotFoundHandler((request, reply) => {
  reply.status(404).send({ error: "Route not found" });
});

fastify.setErrorHandler((error, request, reply) => {
  console.error('Unhandled error:', error);
  reply.status(500).send({ error: "Internal server error" });
});

const PORT = process.env.PORT || 4000;
fastify.listen({ port: PORT, host: '0.0.0.0' }, (err, address) => {
  if (err) throw err;
  console.log(`🚀 Fastify server running at ${address}`);
});
